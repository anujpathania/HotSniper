modules = ('splash2', 'parsec', 'cpu2006', 'npb', 'jikes', 'local')
