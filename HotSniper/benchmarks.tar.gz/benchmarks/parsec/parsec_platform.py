PLATFORM = 'gcc-sniper'
