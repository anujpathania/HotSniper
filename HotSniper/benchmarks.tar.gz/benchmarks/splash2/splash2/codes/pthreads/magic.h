#define MEMSYS_ON  { parmacs_roi_begin(); }
#define MEMSYS_OFF { parmacs_roi_end(); }
