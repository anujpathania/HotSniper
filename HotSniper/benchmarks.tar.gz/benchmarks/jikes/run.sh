#!/bin/bash

"$@"
